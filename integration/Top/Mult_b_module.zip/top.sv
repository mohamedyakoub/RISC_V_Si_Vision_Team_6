module testbensh_top;
    paramter CLK_PERIOD = 10ns;  
    
    // Clock generation
    bit clk_tb;
    logic rst_n_tb;

    // Clock generation
    always #(CLK_PERIOD/2) clk_tb=~clk_tb;

    // Interfaces instantiation
    data_if data_intf (clk_tb);
    ins_if  inst_intf (clk_tb);  

    cv32e40p_top DUT (
        // Clock and Reset
        .clk_i          (clk_tb),
        .rst_ni         (rst_n_tb),

        .pulp_clock_en_i(1'b0),  // PULP clock enable (only used if COREV_CLUSTER = 1)
        .scan_cg_en_i   (1'b0),  // Enable all clock gates for testing

        // Core ID, Cluster ID, debug mode halt address and boot address are considered more or less static
        .boot_addr_i            (),
        .mtvec_addr_i           (),
        .dm_halt_addr_i         (),
        .hart_id_i              (),
        .dm_exception_addr_i    (),

        // Instruction memory interface
        .instr_req_o        (inst_intf.instr_req_o),
        .instr_gnt_i        (inst_intf.instr_gnt_i),
        .instr_rvalid_i     (inst_intf.instr_rvalid_i),
        .instr_addr_o       (inst_intf.instr_addr_o),
        .instr_rdata_i      (inst_intf.instr_rdata_i),

        // Data memory interface
        .data_req_o     (data_intf.data_req_o),
        .data_gnt_i     (data_intf.data_gnt_i),
        .data_rvalid_i  (data_intf.data_rvalid_i),
        .data_we_o      (data_intf.data_we_o),
        .data_be_o      (data_intf.data_be_o),
        .data_addr_o    (data_intf.data_addr_o),
        .data_wdata_o   (data_intf.data_wdata_o),
        .data_rdata_i   (data_intf.data_rdata_i),

        // Interrupt inputs
        .irq_i      (),  // CLINT interrupts + CLINT extension interrupts
        .irq_ack_o  (),
        .irq_id_o   (),

        // Debug Interface
        .debug_req_i        (),
        .debug_havereset_o  (),
        .debug_running_o    (),
        .debug_halted_o     (),

        // CPU Control Signals
        .fetch_enable_i     (),
        .core_sleep_o       ()  
    );

    bind cv32e40p_top mult_bind u_mult_bind(.if(clk_tb));
    bind cv32e40p_top aluNdiv_bind u_mult_bind(.if(clk_tb));
    bind testbensh_top.DUT reg_bind u_mult_bind(.if(clk_tb));
endmodule