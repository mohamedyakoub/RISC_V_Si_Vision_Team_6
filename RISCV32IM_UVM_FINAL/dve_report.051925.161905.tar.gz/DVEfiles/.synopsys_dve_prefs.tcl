# DVE version V-2023.12-1
# Preferences written on Thu Dec 26 14:16:43 2024
gui_set_var -name {read_pref_file} -value {true}
gui_set_pref_value -category {Globals} -key {cbug_fifo_dump_enable_proc} -value {false}
gui_create_pref_key -category {Globals} -key {load_detail_for_funcov} -value_type {bool} -value {false}
gui_set_var -name {read_pref_file} -value {false}
